<?php require "config.php"; header_html("Home"); ?>
<section class="hero"><div><span class="eyebrow">LEARN · PRACTICE · SUCCEED</span>
<h1>Test your knowledge.<br><span>Track your progress.</span></h1>
<p>A simple online examination platform for students and teachers. Take timed quizzes and get your results instantly.</p>
<div class="actions"><a class="btn" href="<?= !empty($_SESSION['user_id']) ? 'dashboard.php' : 'register.php' ?>">Get Started</a>
<a class="btn secondary" href="login.php">Student Login</a></div></div>
<div class="hero-card"><div class="mini-icon">✓</div><h3>Ready for your next quiz?</h3>
<p>Answer multiple-choice questions, submit your attempt and view your score.</p>
<div class="progress"><span></span></div><small>Simple · Fast · Convenient</small></div></section>
<section class="features"><h2>Everything you need</h2><div class="feature-grid">
<div class="feature"><b>⏱</b><h3>Timed quizzes</h3><p>Complete each examination within its time limit.</p></div>
<div class="feature"><b>✓</b><h3>Instant results</h3><p>Get your marks automatically after submission.</p></div>
<div class="feature"><b>▤</b><h3>Result history</h3><p>Review your previous quiz attempts.</p></div></div></section>
<?php footer_html(); ?>