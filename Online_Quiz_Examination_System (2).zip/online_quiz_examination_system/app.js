document.addEventListener("DOMContentLoaded", () => {
  const timer = document.getElementById("timer");
  const form = document.getElementById("quiz-form");
  if (!timer || !form) return;
  let remaining = Number(timer.dataset.minutes || 10) * 60;
  const render = () => {
    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    timer.textContent = `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
  };
  render();
  const interval = setInterval(() => {
    remaining--;
    render();
    if (remaining <= 0) {
      clearInterval(interval);
      alert("Time is over. Your quiz will be submitted automatically.");
      form.submit();
    }
  }, 1000);
});