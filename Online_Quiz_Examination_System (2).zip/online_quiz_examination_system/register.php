<?php
require "config.php";
$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $name = trim($_POST["name"] ?? "");
    $email = strtolower(trim($_POST["email"] ?? ""));
    $pass = $_POST["password"] ?? "";
    if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6) {
        $error = "Enter your name, a valid email and a password of at least 6 characters.";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email=?");
        $check->execute([$email]);
        if ($check->fetch()) $error = "This email is already registered.";
        else {
            $stmt = $pdo->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'student')");
            $stmt->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);
            header("Location: login.php?registered=1"); exit;
        }
    }
}
header_html("Create account"); ?>
<div class="form-card"><h1>Create student account</h1><p class="muted">Register to start taking quizzes.</p>
<?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<label>Full name</label><input name="name" required maxlength="100" placeholder="Your name">
<label>Email address</label><input type="email" name="email" required placeholder="you@example.com">
<label>Password</label><input type="password" name="password" minlength="6" required placeholder="At least 6 characters">
<button class="btn full">Create Account</button></form><p class="muted center">Already registered? <a href="login.php">Login</a></p></div>
<?php footer_html(); ?>