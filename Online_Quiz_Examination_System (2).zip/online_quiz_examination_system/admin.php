<?php
require "config.php"; require_admin(); $message = ""; $error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf(); $action = $_POST["action"] ?? "";
    if ($action === "add_quiz") {
        $title = trim($_POST["title"] ?? ""); $desc = trim($_POST["description"] ?? "");
        $duration = max(1,min(180,(int)($_POST["duration"] ?? 10)));
        if ($title !== "") { $s=$pdo->prepare("INSERT INTO quizzes(title,description,duration) VALUES(?,?,?)"); $s->execute([$title,$desc,$duration]); $message="Quiz created."; }
    } elseif ($action === "toggle") {
        $s=$pdo->prepare("UPDATE quizzes SET is_active=1-is_active WHERE id=?"); $s->execute([(int)$_POST["quiz_id"]]); $message="Quiz status updated.";
    } elseif ($action === "delete") {
        $s=$pdo->prepare("DELETE FROM quizzes WHERE id=?"); $s->execute([(int)$_POST["quiz_id"]]); $message="Quiz deleted.";
    } elseif ($action === "add_question") {
        $quiz=(int)$_POST["quiz_id"]; $question=trim($_POST["question"]??"");
        $opts=[trim($_POST["a"]??""),trim($_POST["b"]??""),trim($_POST["c"]??""),trim($_POST["d"]??"")];
        $correct=strtoupper($_POST["correct"]??"");
        if ($question && !in_array("",$opts,true) && in_array($correct,["A","B","C","D"],true)) {
            $s=$pdo->prepare("INSERT INTO questions(quiz_id,question,option_a,option_b,option_c,option_d,correct_option) VALUES(?,?,?,?,?,?,?)");
            $s->execute([$quiz,$question,$opts[0],$opts[1],$opts[2],$opts[3],$correct]); $message="Question added.";
        } else $error="Fill in the question, all four options and correct answer.";
    } elseif ($action === "delete_question") {
        $s=$pdo->prepare("DELETE FROM questions WHERE id=?"); $s->execute([(int)$_POST["question_id"]]); $message="Question deleted.";
    }
}
$quizzes=$pdo->query("SELECT q.*,(SELECT COUNT(*) FROM questions WHERE quiz_id=q.id) AS n FROM quizzes q ORDER BY q.created_at DESC")->fetchAll();
$selected=(int)($_GET["quiz"]??($quizzes[0]["id"]??0));
$qstmt=$pdo->prepare("SELECT * FROM questions WHERE quiz_id=? ORDER BY id"); $qstmt->execute([$selected]); $questions=$qstmt->fetchAll();
header_html("Admin Panel"); ?>
<div class="page-heading"><div><span class="eyebrow">ADMINISTRATION</span><h1>Admin Panel</h1><p class="muted">Create quizzes and manage questions.</p></div></div>
<?php if($message): ?><div class="success"><?= e($message) ?></div><?php endif; ?><?php if($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
<div class="admin-grid"><section class="panel"><h2>Create a quiz</h2><form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="add_quiz">
<label>Quiz title</label><input name="title" required><label>Description</label><textarea name="description" rows="3"></textarea>
<label>Duration (minutes)</label><input type="number" name="duration" min="1" max="180" value="10" required><button class="btn full">Create Quiz</button></form></section>
<section class="panel"><h2>Existing quizzes</h2><?php foreach($quizzes as $q): ?><div class="admin-quiz"><div><b><?= e($q["title"]) ?></b><small><?= (int)$q["n"] ?> questions · <?= $q["is_active"]?"Active":"Hidden" ?></small></div>
<a href="admin.php?quiz=<?= (int)$q["id"] ?>">Manage</a>
<form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="quiz_id" value="<?= (int)$q["id"] ?>"><button class="link-button">Toggle</button></form>
<form method="post" onsubmit="return confirm('Delete this quiz and its questions?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="quiz_id" value="<?= (int)$q["id"] ?>"><button class="link-button danger">Delete</button></form></div><?php endforeach; ?>
<?php if(!$quizzes): ?><p class="muted">No quizzes created yet.</p><?php endif; ?></section></div>
<?php if($selected): ?><section class="panel section-gap"><h2>Add question</h2><form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="add_question"><input type="hidden" name="quiz_id" value="<?= $selected ?>">
<label>Question</label><textarea name="question" required rows="2"></textarea><div class="two-col">
<?php foreach(["a","b","c","d"] as $letter): ?><div><label>Option <?= strtoupper($letter) ?></label><input name="<?= $letter ?>" required></div><?php endforeach; ?></div>
<label>Correct option</label><select name="correct"><option>A</option><option>B</option><option>C</option><option>D</option></select><button class="btn">Add Question</button></form>
<h2 class="section-gap">Questions in selected quiz</h2><?php foreach($questions as $i=>$q): ?><div class="question-row"><span><?= $i+1 ?>. <?= e($q["question"]) ?> <small>(Answer: <?= e($q["correct_option"]) ?>)</small></span>
<form method="post" onsubmit="return confirm('Delete this question?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_question"><input type="hidden" name="question_id" value="<?= (int)$q["id"] ?>"><button class="link-button danger">Delete</button></form></div><?php endforeach; ?></section><?php endif; ?>
<?php footer_html(); ?>