<?php
require "config.php"; $error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $email = strtolower(trim($_POST["email"] ?? ""));
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email=?");
    $stmt->execute([$email]); $user = $stmt->fetch();
    if ($user && password_verify($_POST["password"] ?? "", $user["password"])) {
        session_regenerate_id(true);
        $_SESSION["user_id"] = $user["id"]; $_SESSION["name"] = $user["name"]; $_SESSION["role"] = $user["role"];
        header("Location: " . ($user["role"] === "admin" ? "admin.php" : "dashboard.php")); exit;
    } else $error = "Incorrect email or password.";
}
header_html("Login"); ?>
<div class="form-card"><h1>Welcome back</h1><p class="muted">Login to your QuizMaster account.</p>
<?php if (isset($_GET["registered"])): ?><div class="success">Registration successful. Please log in.</div><?php endif; ?>
<?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<label>Email address</label><input type="email" name="email" required>
<label>Password</label><input type="password" name="password" required>
<button class="btn full">Login</button></form><p class="muted center">New student? <a href="register.php">Create account</a></p>
<p class="hint">To create an admin account, follow the instructions in README.txt.</p></div>
<?php footer_html(); ?>