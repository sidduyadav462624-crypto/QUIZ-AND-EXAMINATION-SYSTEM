<?php
require "config.php"; require_login();
$stmt = $pdo->query("SELECT q.*, (SELECT COUNT(*) FROM questions WHERE quiz_id=q.id) AS question_count FROM quizzes q WHERE q.is_active=1 ORDER BY q.created_at DESC");
$quizzes = $stmt->fetchAll();
$hist = $pdo->prepare("SELECT a.score,a.total,a.submitted_at,q.title FROM attempts a JOIN quizzes q ON q.id=a.quiz_id WHERE a.user_id=? ORDER BY a.submitted_at DESC LIMIT 8");
$hist->execute([$_SESSION["user_id"]]); $history = $hist->fetchAll();
header_html("Student Dashboard"); ?>
<div class="page-heading"><div><span class="eyebrow">STUDENT AREA</span><h1>Hello, <?= e($_SESSION["name"]) ?>!</h1><p class="muted">Choose a quiz and do your best.</p></div></div>
<h2>Available quizzes</h2><div class="quiz-grid">
<?php foreach ($quizzes as $q): ?><article class="quiz-card"><span class="tag">ONLINE QUIZ</span><h3><?= e($q["title"]) ?></h3>
<p><?= e($q["description"]) ?></p><div class="meta"><?= (int)$q["question_count"] ?> questions · <?= (int)$q["duration"] ?> minutes</div>
<?php if ($q["question_count"] > 0): ?><a class="btn full" href="take_quiz.php?id=<?= (int)$q["id"] ?>">Start Quiz</a><?php else: ?><button class="btn full" disabled>No questions yet</button><?php endif; ?></article>
<?php endforeach; ?>
<?php if (!$quizzes): ?><div class="empty">No quizzes are available right now. Please check again later.</div><?php endif; ?></div>
<h2 class="section-gap">Recent attempts</h2><div class="table-wrap"><table><thead><tr><th>Quiz</th><th>Score</th><th>Date</th></tr></thead><tbody>
<?php foreach ($history as $h): ?><tr><td><?= e($h["title"]) ?></td><td><?= (int)$h["score"] ?> / <?= (int)$h["total"] ?></td><td><?= e($h["submitted_at"]) ?></td></tr><?php endforeach; ?>
<?php if (!$history): ?><tr><td colspan="3">No attempts yet.</td></tr><?php endif; ?></tbody></table></div>
<?php footer_html(); ?>