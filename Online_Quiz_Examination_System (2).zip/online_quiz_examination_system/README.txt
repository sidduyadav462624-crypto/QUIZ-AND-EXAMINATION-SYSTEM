ONLINE QUIZ & EXAMINATION SYSTEM
Technology: HTML5, CSS3, JavaScript, PHP, MySQL, XAMPP

SETUP USING XAMPP
1. Install and open XAMPP.
2. Start Apache and MySQL.
3. Copy the folder "online_quiz_examination_system" into:
   C:\xampp\htdocs\
4. Open http://localhost/phpmyadmin
5. Choose Import and import the database.sql file from this project.
6. Check config.php. Default XAMPP MySQL username is root and password is blank.
7. Open http://localhost/online_quiz_examination_system/
8. Register a student account.
9. To make your account an administrator:
   - Open phpMyAdmin, select online_quiz, then users.
   - Find your account and change role from student to admin.
   - Log out and log in again.
10. Open Admin from the navigation bar. Create a quiz and add questions.

ADMIN LOGIN NOTE
For reliability, create your own account and change its role to admin using phpMyAdmin as explained above.
The example admin row in database.sql is only a placeholder and its password may not match.
Do not use demo credentials on a public server.

PROJECT FEATURES
- Student registration and login with password hashing
- Student dashboard and active quiz list
- MCQ quiz with countdown timer and auto-submit in browser
- Automatic score calculation on server
- Result page and previous attempt history
- Admin quiz creation, activation/deactivation, deletion
- Add and delete MCQ questions
- Prepared SQL statements and basic CSRF protection

IMPORTANT
This is a college mini-project starter intended for local demonstration.
Before public deployment, add server-side exam time enforcement, stronger admin controls,
rate limiting, audit logging, HTTPS, backups, and more extensive testing.
