<?php
require "config.php"; require_login();
$id = (int)($_GET["id"] ?? 0);
$qstmt = $pdo->prepare("SELECT * FROM quizzes WHERE id=? AND is_active=1"); $qstmt->execute([$id]); $quiz = $qstmt->fetch();
if (!$quiz) { http_response_code(404); exit("Quiz not found."); }
$qs = $pdo->prepare("SELECT id,question,option_a,option_b,option_c,option_d FROM questions WHERE quiz_id=? ORDER BY id");
$qs->execute([$id]); $questions = $qs->fetchAll();
if (!$questions) exit("This quiz does not have questions yet.");
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $answers = $_POST["answers"] ?? []; $score = 0; $total = count($questions);
    foreach ($questions as $question) {
        $chosen = strtoupper($answers[$question["id"]] ?? "");
        if ($chosen !== "" && $chosen === $question["correct_option"]) $score++;
    }
    $ins = $pdo->prepare("INSERT INTO attempts(user_id,quiz_id,score,total) VALUES(?,?,?,?)");
    $ins->execute([$_SESSION["user_id"],$id,$score,$total]); $attemptId = $pdo->lastInsertId();
    header("Location: result.php?id=" . $attemptId); exit;
}
header_html($quiz["title"]); ?>
<div class="exam-header"><div><span class="eyebrow">EXAMINATION</span><h1><?= e($quiz["title"]) ?></h1><p class="muted"><?= count($questions) ?> questions · Choose one answer per question.</p></div>
<div class="timer-box">TIME LEFT <strong id="timer" data-minutes="<?= (int)$quiz["duration"] ?>"><?= (int)$quiz["duration"] ?>:00</strong></div></div>
<form method="post" id="quiz-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<?php foreach ($questions as $i => $question): ?><section class="question-card"><h3><?= $i+1 ?>. <?= e($question["question"]) ?></h3>
<?php foreach (["A"=>"option_a","B"=>"option_b","C"=>"option_c","D"=>"option_d"] as $letter=>$field): ?>
<label class="option"><input type="radio" name="answers[<?= (int)$question["id"] ?>]" value="<?= $letter ?>"> <span><b><?= $letter ?>.</b> <?= e($question[$field]) ?></span></label>
<?php endforeach; ?></section><?php endforeach; ?>
<button class="btn submit-btn" type="submit" onclick="return confirm('Submit your quiz now?')">Submit Quiz</button></form>
<?php footer_html(); ?>