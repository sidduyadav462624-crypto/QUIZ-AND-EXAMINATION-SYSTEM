<?php
require "config.php"; require_login();
$id = (int)($_GET["id"] ?? 0);
$stmt = $pdo->prepare("SELECT a.*,q.title FROM attempts a JOIN quizzes q ON q.id=a.quiz_id WHERE a.id=? AND a.user_id=?");
$stmt->execute([$id,$_SESSION["user_id"]]); $a = $stmt->fetch();
if (!$a) { http_response_code(404); exit("Result not found."); }
$percent = $a["total"] ? round($a["score"]/$a["total"]*100) : 0;
header_html("Quiz Result"); ?>
<div class="result-card"><span class="eyebrow">QUIZ COMPLETED</span><h1><?= e($a["title"]) ?></h1>
<div class="score-circle"><strong><?= $percent ?>%</strong><span>YOUR SCORE</span></div>
<h2><?= (int)$a["score"] ?> / <?= (int)$a["total"] ?> marks</h2><p class="muted">Submitted: <?= e($a["submitted_at"]) ?></p>
<a class="btn" href="dashboard.php">Back to Dashboard</a></div>
<?php footer_html(); ?>