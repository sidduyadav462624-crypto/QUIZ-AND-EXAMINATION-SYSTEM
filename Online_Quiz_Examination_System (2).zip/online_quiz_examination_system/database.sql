CREATE DATABASE IF NOT EXISTS online_quiz CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE online_quiz;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('student','admin') NOT NULL DEFAULT 'student',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS quizzes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(180) NOT NULL,
 description TEXT,
 duration INT NOT NULL DEFAULT 10,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS questions (
 id INT AUTO_INCREMENT PRIMARY KEY,
 quiz_id INT NOT NULL,
 question TEXT NOT NULL,
 option_a VARCHAR(500) NOT NULL,
 option_b VARCHAR(500) NOT NULL,
 option_c VARCHAR(500) NOT NULL,
 option_d VARCHAR(500) NOT NULL,
 correct_option ENUM('A','B','C','D') NOT NULL,
 FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS attempts (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 quiz_id INT NOT NULL,
 score INT NOT NULL,
 total INT NOT NULL,
 submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

-- Demo administrator. Change this password after first login.
INSERT INTO users(name,email,password,role)
SELECT 'Administrator','admin@quiz.com',
'$2y$10$7u8q0vYyXz3j1pYpK8dU6eJrH2WQ3p5sQ1uP4x7dZ0a8mV6cN9b2K','admin'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='admin@quiz.com');

-- The demo password hash above may not match on every PHP setup.
-- Recommended: register a student account, then create your own admin row
-- by changing role='admin' for that user's email in phpMyAdmin.
