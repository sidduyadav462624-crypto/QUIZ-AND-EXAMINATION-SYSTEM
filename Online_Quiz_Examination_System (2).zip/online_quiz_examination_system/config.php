<?php
$host = "localhost";
$dbname = "online_quiz";
$username = "root";
$password = "";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    die("Database connection failed. Check config.php and import database.sql.");
}
if (session_status() === PHP_SESSION_NONE) session_start();

function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function require_login() {
    if (empty($_SESSION['user_id'])) { header("Location: login.php"); exit; }
}
function require_admin() {
    require_login();
    if (($_SESSION['role'] ?? '') !== 'admin') { header("Location: dashboard.php"); exit; }
}
function csrf_token() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
        !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400); exit("Invalid request. Please go back and try again.");
    }
}
function header_html($title = "QuizMaster") { ?>
<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | QuizMaster</title><link rel="stylesheet" href="style.css"></head><body>
<header class="topbar"><a class="brand" href="index.php">QuizMaster</a>
<nav><a href="index.php">Home</a>
<?php if (!empty($_SESSION['user_id'])): ?>
<a href="dashboard.php">Dashboard</a>
<?php if (($_SESSION['role'] ?? '') === 'admin'): ?><a href="admin.php">Admin</a><?php endif; ?>
<a href="logout.php">Logout</a>
<?php else: ?><a href="login.php">Login</a><a class="navbutton" href="register.php">Register</a><?php endif; ?>
</nav></header><main class="container">
<?php }
function footer_html() { ?></main><footer>Online Quiz & Examination System · Minor Project</footer>
<script src="app.js"></script></body></html><?php }
?>